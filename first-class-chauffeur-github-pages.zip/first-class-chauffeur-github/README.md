# First Class Chauffeur Website

GitHub Pages ready website.

## Upload Instructions
1. Create a new GitHub repository.
2. Upload `index.html`, `style.css`, and this `README.md`.
3. Go to Settings → Pages.
4. Under “Build and deployment,” choose “Deploy from a branch.”
5. Select the `main` branch and `/root` folder.
6. Save. GitHub will give you a live website link.
